package Selenium_final;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class testcase_3 {
	WebDriver driver;
	Screen myScreen;
	
	public void invokeBrowser()
	try {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicityWait(30,TimeUnit.SECONDS);
		driver.get("http://www.amazon.ca");
}
}
catch(Exception e) 
{
	
	e.printStackTrace();
}

public void Login()
{
	try {
		Pattern log =  new Pattern("\"C:\\\\Users\\\\Zeel\\\\Desktop\\Login.PNG\"");
		myScreen.wait(log);
		myScreen.click(log);
	} 
	catch (Exception e) 
	{
		
		e.printStackTrace();
	}
}
public static void main(String args[])
{
	testcase_3 myObj = testcase_3();
	myObj.invokeBrowser();
	myObj.Login();
}
private static testcase_3 testcase_3() {
	
	return null;
}
}
