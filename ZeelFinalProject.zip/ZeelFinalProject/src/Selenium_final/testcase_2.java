package Selenium_final;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class testcase_2 {
	WebDriver driver;
	Screen myScreen;
	public void invokeBrowser()
	try {
		
			System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicityWait(30,TimeUnit.SECONDS);
			driver.get("http://www.amazon.ca");
		}
}
catch (Exception e) 
	{
		
		e.printStackTrace();
	}
public void HomePageAmazon()
{
	try {
		Pattern homepage =  new Pattern("\"C:\\\\Users\\\\Zeel\\\\Desktop\\Home_page.PNG\"");
		myScreen.wait(homepage,5);
		myScreen.click(homepage);
	} 
	catch (Exception e) 
	{
		
		e.printStackTrace();
	}
}

public static void main(String args[])
{
	testcase_2 myObj = testcase_2();
	myObj.invokeBrowser();
	myObj.HomePageAmazon();
}

private static testcase_2 testcase_2() {
	
	return null;
}
}
