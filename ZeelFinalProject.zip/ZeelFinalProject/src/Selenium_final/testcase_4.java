package Selenium_final;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class testcase_4 {

	
	WebDriver driver;
	Screen myScreen;
	
	public void invokeBrowser()
	try {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicityWait(30,TimeUnit.SECONDS);
		driver.get("http://www.amazon.ca");
}
}
catch(Exception e) 
{
	
	e.printStackTrace();
}

public void Search()
{
	try {
		Pattern  =  new Pattern("\"C:\\\\Users\\\\Zeel\\\\Desktop\\SearchFashion.PNG\"");
		myScreen.wait(search,2);
		myScreen.click(Search);
	} 
	catch (Exception e) 
	{
		
		e.printStackTrace();
	}
}
public static void main(String args[])
{
	testcase_4 myObj = testcase_4();
	myObj.invokeBrowser();
	myObj.Search();
}
private static testcase_3 testcase_3() {
	
	return null;
}
}
