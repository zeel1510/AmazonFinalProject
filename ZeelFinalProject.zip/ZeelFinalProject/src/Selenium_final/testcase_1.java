package Selenium_final;
import java.util.concurrent.*;

public class testcase_1 {

	static WebDriver driver;
	Screen myScreen;
	JavascriptExecutor jse;	
}

public void invokeBrowser()
{
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().deleteAllCookies();
	driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicityWait(30,TimeUnit.SECONDS);
	driver.get("http://www.amazon.ca");
}

public void selectFashion()
try
	{
		myScreen = new Screen();
		Pattern fashion = new Pattern("C:\\Users\\Zeel\\Desktop\\AmazonCategories.PNG");
		
		myScreen.click(fashion);
	}
catch(FindFailed e)
{
	e.printStackTrace();
}
}
public static void main(String args)
{
	testcase_1 myObj = testcase_1();
	myObj.invokeBrowser();
	myObj.selectFashion();
}

private static testcase_1 testcase_1() {
	
	return null;
}
}